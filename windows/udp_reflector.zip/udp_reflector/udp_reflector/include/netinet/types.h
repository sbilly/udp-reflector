

#define u_int8_t  unsigned char
#define u_int16_t unsigned short
#define u_int32_t unsigned int

